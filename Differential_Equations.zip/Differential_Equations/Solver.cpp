#include "Functions/Harmonic.hpp"
#include "Functions/X.hpp"
#include <fstream>
#include <iostream>

/*double evolve(double x, double v, double t, double dt) { //x''+xx'=0


}*/

int main() {

  double dt = 0.01;
  double x = 1; // Initial x
  double v = 0; // Initial velocity
  double t = 0; // Initial t
  int N = 100;  // Number of iterations

  std::ofstream os{"Data/Harmonic.txt"};
  os << t << '\t' << x << '\n';

  harmonic H{2.}; // 2 Hz

  for (int i = 0; i != N; ++i) {

    X S = H(x, v, dt);
    x = S.x;
    v = S.v;
    t += dt;

    os << t << '\t' << x << '\n';
  }

  os.close();
}
