Questo programma si compone di tanti file.
-Per COMPILARLO occorre usare CMAKE, per installarlo fare: sudo apt-get -y install cmake
-I vari file .hpp sono nella cartella "Functions", in cui le funzioni sono state ridefinite come "object functions" con l'operator().
-Nella cartella "Data" vengono messi gli OUTPUT delle risoluzioni numeriche delle eq. diff.
-Il file "Grapher.C" è una macro di ROOT per graficare i dati suddetti nella cartella "Data".

Per COMPILARE il programma:
1)cmake .	(Con il PUNTO, che indica "cartella corrente"!!)
2)make
3)./Solver.exe
