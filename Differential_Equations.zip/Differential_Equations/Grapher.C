//Root macro used to graph data

void Graph(char* path = "Data/Harmonic.txt") {

  TGraph* graph = new TGraph(path, "%lg %lg");

  graph->SetMarkerStyle(7);
  graph->SetMarkerColor(kBlue);
  graph->SetLineColor(kBlue);

  graph->SetTitle("Evolution; Time; x");

  TCanvas* c = new TCanvas("c", "Evolution");
  c->cd();
  graph->Draw();

  c->Print("Graphs/Harmonic.pdf");

}
