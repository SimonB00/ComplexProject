#ifndef HARMONIC_CPP
#define HARMONIC_CPP

#include "X.hpp"
#include <cmath>

class harmonic {

private:
  double f_; // Frequency (Hz)

public:
  harmonic(double f) : f_{f} {}

  X operator()(double x, double v, double dt) {

    v = v - dt * x * std::pow(6.28 * f_, 2); // 6.28 ~ 2pi
    x += v * dt;
    X A{x, v};
    return A;
  }
};

class damped_harmonic {

private:
  double g_;  // gamma, damping factor
  double f0_; // resonance frequency
  double Delta;
  char r; // Regime according to the given constants

public:
  damped_harmonic(double g, double f0) : g_{g}, f0_{f0} {

    Delta = std::pow(g_, 2) - 4 * (6.283185 * f0_);
    if (Delta > 0)
      r = 'o'; // Overdamped
    else if (Delta < 0)
      r = 'u'; // Underdamped
    else
      r = 'c'; // Critic
  }

  X operator()(double x, double v, double dt) {

    v = v - dt * (g_ * v + x * std::pow((6.28 * f0_), 2));
    x += v * dt;
    X A{x, v};
    return A;
  }

  char regime() const { return r; }
};

#endif
