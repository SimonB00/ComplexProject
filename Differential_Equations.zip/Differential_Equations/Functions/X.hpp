#ifndef X_HPP
#define X_HPP

struct X {
double x;
double v;
};

#endif
